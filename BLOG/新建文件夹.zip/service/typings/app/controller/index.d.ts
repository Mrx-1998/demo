// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminMain = require('../../../app/controller/admin/main');
import ExportDefaultMain = require('../../../app/controller/default/main');

declare module 'egg' {
  interface IController {
    admin: {
      main: ExportAdminMain;
    }
    default: {
      main: ExportDefaultMain;
    }
  }
}
